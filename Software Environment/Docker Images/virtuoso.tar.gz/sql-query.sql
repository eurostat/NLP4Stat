user_set_password('dba', 'myCsdL0d');
GRANT SPARQL_UPDATE to "SPARQL";
